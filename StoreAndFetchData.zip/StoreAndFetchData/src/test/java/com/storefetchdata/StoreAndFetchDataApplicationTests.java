package com.storefetchdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreAndFetchDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
